package com.bibitaries.sepakbola.ui.base.favorite

import androidx.lifecycle.ViewModel

class FavoriteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}