package com.bibitaries.sepakbola.data.model

data class OlahragaList(
    val data: List<Olahraga> = arrayListOf(),
    val length: Int = 0,
    val status:  Int = 0
)
